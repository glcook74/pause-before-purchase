
-- Create profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  first_name TEXT,
  email TEXT,
  is_pro BOOLEAN NOT NULL DEFAULT false,
  pro_activated_at TIMESTAMPTZ,
  total_points INTEGER NOT NULL DEFAULT 0,
  current_streak INTEGER NOT NULL DEFAULT 0,
  longest_streak INTEGER NOT NULL DEFAULT 0,
  last_pause_date DATE,
  total_pauses INTEGER NOT NULL DEFAULT 0,
  total_saved INTEGER NOT NULL DEFAULT 0,
  money_saved_estimate NUMERIC NOT NULL DEFAULT 0,
  profile_type TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create pauses table
CREATE TABLE public.pauses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  site TEXT NOT NULL,
  product TEXT,
  price NUMERIC,
  choice_type TEXT NOT NULL,
  outcome TEXT NOT NULL,
  points_earned INTEGER NOT NULL DEFAULT 0,
  alternative_chosen TEXT
);

-- Create saved_items table
CREATE TABLE public.saved_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  site TEXT NOT NULL,
  product TEXT,
  price NUMERIC,
  url TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  removed_at TIMESTAMPTZ
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pauses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_items ENABLE ROW LEVEL SECURITY;

-- Profiles RLS: users can only access their own row
CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Pauses RLS
CREATE POLICY "Users can view own pauses" ON public.pauses FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own pauses" ON public.pauses FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own pauses" ON public.pauses FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own pauses" ON public.pauses FOR DELETE USING (auth.uid() = user_id);

-- Saved items RLS
CREATE POLICY "Users can view own saved items" ON public.saved_items FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own saved items" ON public.saved_items FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own saved items" ON public.saved_items FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own saved items" ON public.saved_items FOR DELETE USING (auth.uid() = user_id);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, first_name, email)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data ->> 'first_name',
    NEW.email
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
