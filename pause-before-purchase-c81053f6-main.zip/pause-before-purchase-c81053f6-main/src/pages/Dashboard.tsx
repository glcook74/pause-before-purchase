import { useEffect, useState, useCallback } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from "recharts";
import logo from "@/assets/logo-hero.png";

// ── Types ──
interface Profile {
  first_name: string | null;
  total_points: number;
  current_streak: number;
  total_pauses: number;
  total_saved: number;
  money_saved_estimate: number;
  is_pro: boolean;
  pro_activated_at: string | null;
  created_at: string;
  email: string | null;
}

interface Pause {
  id: string;
  created_at: string;
  choice_type: string;
  outcome: string;
  price: number | null;
  product: string | null;
  site: string;
  points_earned: number;
}

interface SavedItem {
  id: string;
  site: string;
  product: string | null;
  price: number | null;
  url: string | null;
  created_at: string;
  status: string;
}

// ── Badge milestones ──
const MILESTONES = [
  { points: 0, name: "Starter Pauser" },
  { points: 100, name: "Redirect Master" },
  { points: 250, name: "Impulse Interceptor" },
  { points: 500, name: "Delay Champion" },
  { points: 1000, name: "ADHD Money Hero" },
];

function getCurrentMilestone(points: number) {
  let current = MILESTONES[0];
  let next = MILESTONES[1];
  for (let i = MILESTONES.length - 1; i >= 0; i--) {
    if (points >= MILESTONES[i].points) {
      current = MILESTONES[i];
      next = MILESTONES[i + 1] || null;
      break;
    }
  }
  return { current, next };
}

// ── Achievement definitions ──
const ACHIEVEMENTS = [
  { id: "first-pause", emoji: "⏸", name: "First Pause", condition: "Complete 1 pause", check: (p: Profile, pauses: Pause[], saved: SavedItem[]) => p.total_pauses >= 1 },
  { id: "redirect", emoji: "🔄", name: "Redirect", condition: "Redirect 1 impulse", check: (_p: Profile, pauses: Pause[]) => pauses.some(pa => pa.choice_type === "impulsive" && ["redirected", "saved"].includes(pa.outcome)) },
  { id: "saver", emoji: "💾", name: "Saver", condition: "Save 1 item for later", check: (_p: Profile, _pauses: Pause[], saved: SavedItem[]) => saved.length > 0 },
  { id: "week-warrior", emoji: "🔥", name: "Week Warrior", condition: "7 day streak", check: (p: Profile) => p.current_streak >= 7 || (p as any).longest_streak >= 7 },
  { id: "budget-guardian", emoji: "🛡️", name: "Budget Guardian", condition: "£100 potentially saved", check: (p: Profile) => p.money_saved_estimate >= 100 },
  { id: "impulse-interceptor", emoji: "🎯", name: "Impulse Interceptor", condition: "Redirect 25 impulses", check: (_p: Profile, pauses: Pause[]) => pauses.filter(pa => pa.choice_type === "impulsive" && ["redirected", "saved"].includes(pa.outcome)).length >= 25 },
  { id: "month-master", emoji: "📅", name: "Month Master", condition: "30 day streak", check: (p: Profile) => p.current_streak >= 30 || (p as any).longest_streak >= 30 },
  { id: "money-hero", emoji: "💰", name: "Money Hero", condition: "£500 potentially saved", check: (p: Profile) => p.money_saved_estimate >= 500 },
];

// ── Helpers ──
function daysAgo(dateStr: string) {
  return Math.floor((Date.now() - new Date(dateStr).getTime()) / 86400000);
}

function agePill(dateStr: string) {
  const d = daysAgo(dateStr);
  if (d < 3) return { label: "Fresh save", className: "bg-green-100 text-green-800 border-green-200" };
  if (d <= 7) return { label: "Still thinking?", className: "bg-amber-100 text-amber-800 border-amber-200" };
  return { label: "Still want it?", className: "bg-primary/10 text-primary border-primary/20" };
}

function formatDay(dateStr: string) {
  const d = new Date(dateStr);
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return `${days[d.getDay()]} ${d.getDate()}`;
}

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [profile, setProfile] = useState<Profile | null>(null);
  const [weeklyPauses, setWeeklyPauses] = useState<Pause[]>([]);
  const [allPauses, setAllPauses] = useState<Pause[]>([]);
  const [chartPauses, setChartPauses] = useState<Pause[]>([]);
  const [savedItems, setSavedItems] = useState<SavedItem[]>([]);
  const [allSavedItems, setAllSavedItems] = useState<SavedItem[]>([]);
  const [weeklySavedItems, setWeeklySavedItems] = useState<SavedItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    if (!user) return;
    setLoading(true);

    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 86400000).toISOString();
    const fourteenDaysAgo = new Date(now.getTime() - 14 * 86400000).toISOString();

    const [profileRes, weeklyPausesRes, chartPausesRes, allPausesRes, savedRes, allSavedRes, weeklySavedRes] = await Promise.all([
      supabase.from("profiles").select("first_name, total_points, current_streak, total_pauses, total_saved, money_saved_estimate, is_pro, pro_activated_at, created_at, email").eq("id", user.id).single(),
      supabase.from("pauses").select("*").eq("user_id", user.id).gte("created_at", sevenDaysAgo),
      supabase.from("pauses").select("*").eq("user_id", user.id).gte("created_at", fourteenDaysAgo),
      supabase.from("pauses").select("*").eq("user_id", user.id),
      supabase.from("saved_items").select("*").eq("user_id", user.id).eq("status", "pending").order("created_at", { ascending: false }),
      supabase.from("saved_items").select("*").eq("user_id", user.id),
      supabase.from("saved_items").select("*").eq("user_id", user.id).gte("created_at", sevenDaysAgo),
    ]);

    if (profileRes.data) setProfile(profileRes.data);
    if (weeklyPausesRes.data) setWeeklyPauses(weeklyPausesRes.data);
    if (chartPausesRes.data) setChartPauses(chartPausesRes.data);
    if (allPausesRes.data) setAllPauses(allPausesRes.data);
    if (savedRes.data) setSavedItems(savedRes.data);
    if (allSavedRes.data) setAllSavedItems(allSavedRes.data);
    if (weeklySavedRes.data) setWeeklySavedItems(weeklySavedRes.data);

    setLoading(false);
  }, [user]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const handleMovedOn = async (item: SavedItem) => {
    if (!user) return;
    // Update saved_items status
    await supabase.from("saved_items").update({ status: "removed", removed_at: new Date().toISOString() }).eq("id", item.id);
    // Add +5 points
    if (profile) {
      await supabase.from("profiles").update({ total_points: profile.total_points + 5 }).eq("id", user.id);
    }
    // Insert abandoned pause
    await supabase.from("pauses").insert({
      user_id: user.id,
      site: item.site,
      product: item.product,
      price: item.price,
      choice_type: "impulsive",
      outcome: "abandoned",
      points_earned: 5,
    });
    toast({ title: "Nice one! 🎉", description: "+5 Delay Points earned. You've moved on." });
    fetchData();
  };

  const handleChangePassword = async () => {
    if (!profile?.email) return;
    const { error } = await supabase.auth.resetPasswordForEmail(profile.email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Check your email", description: "Password reset link sent." });
    }
  };

  const handleDeleteAccount = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-account`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${session?.access_token}`,
          "Content-Type": "application/json",
        },
      });
      if (!res.ok) throw new Error("Failed to delete account");
      await signOut();
      navigate("/", { state: { deleted: true } });
    } catch {
      toast({ title: "Error", description: "Could not delete account. Please try again.", variant: "destructive" });
    }
  };

  // ── Computed values ──
  const weeklyPauseCount = weeklyPauses.length;
  const weeklySaved = weeklySavedItems.reduce((sum, s) => sum + (s.price || 0), 0);
  const impulsesRedirected = weeklyPauses.filter(p => p.choice_type === "impulsive" && ["redirected", "saved"].includes(p.outcome)).length;
  const plannedSaved = weeklyPauses.filter(p => p.outcome === "saved" && p.choice_type === "planned").length;

  const milestone = getCurrentMilestone(profile?.total_points || 0);
  const progressPercent = milestone.next
    ? ((profile?.total_points || 0) - milestone.current.points) / (milestone.next.points - milestone.current.points) * 100
    : 100;
  const pointsToNext = milestone.next ? milestone.next.points - (profile?.total_points || 0) : 0;

  // Chart data — last 14 days
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const chartData = Array.from({ length: 14 }, (_, i) => {
    const date = new Date(today.getTime() - (13 - i) * 86400000);
    const dateStr = date.toISOString().split("T")[0];
    const count = chartPauses.filter(p => p.created_at.split("T")[0] === dateStr).length;
    return { date: dateStr, label: formatDay(date.toISOString()), count, isToday: i === 13 };
  });
  const hasChartData = chartData.some(d => d.count > 0);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* ── SECTION 1: TOP NAV ── */}
      <nav className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2">
            <img src={logo} alt="Dopamine Delay" className="h-8" />
          </a>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground">
              <span className="sm:hidden">{profile?.first_name || profile?.email?.split("@")[0] || "Account"}</span>
              <span className="hidden sm:inline">{profile?.first_name ? `${profile.first_name}'s account` : profile?.email?.split("@")[0] ? `${profile.email.split("@")[0]}'s account` : "My account"}</span>
            </span>
            <Button variant="outline" size="sm" onClick={handleSignOut}>Sign out</Button>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-10">

        {/* ── SECTION 2: POINTS HERO ── */}
        <section className="flex flex-col items-center text-center">
          <div className="w-[120px] h-[120px] rounded-full border-4 border-accent bg-accent/10 flex flex-col items-center justify-center mb-4">
            <span className="text-3xl font-bold font-heading text-accent">{profile?.total_points ?? 0}</span>
            <span className="text-xs text-accent font-medium">Delay Points</span>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-6">
            <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-card border border-border text-sm">
              🔥 <strong>{profile?.current_streak ?? 0}</strong> day streak
            </span>
            <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-card border border-border text-sm">
              ⏸ <strong>{profile?.total_pauses ?? 0}</strong> pauses
            </span>
            <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-card border border-border text-sm">
              💾 <strong>{profile?.total_saved ?? 0}</strong> saved
            </span>
          </div>

          <div className="w-full max-w-md">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span className="font-medium text-accent">{milestone.current.name}</span>
              {milestone.next && <span>{milestone.next.name}</span>}
            </div>
            <Progress value={progressPercent} className="h-3" />
            {milestone.next && (
              <p className="text-sm text-muted-foreground mt-2">
                {pointsToNext} points to <strong>{milestone.next.name}</strong>
              </p>
            )}
            {!milestone.next && (
              <p className="text-sm text-accent mt-2 font-medium">🏆 Maximum rank achieved!</p>
            )}
          </div>
        </section>

        {/* ── SECTION 3: THIS WEEK ── */}
        <section>
          <h2 className="text-xl font-heading font-semibold text-foreground mb-4">This week</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Card>
              <CardHeader className="pb-1 pt-4 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground">Pauses</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <p className="text-2xl font-bold text-foreground">{weeklyPauseCount}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1 pt-4 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground">Potentially saved</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <p className="text-2xl font-bold text-accent">£{weeklySaved.toFixed(2)}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1 pt-4 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground">Impulses redirected</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <p className="text-2xl font-bold text-foreground">{impulsesRedirected}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-1 pt-4 px-4">
                <CardTitle className="text-xs font-medium text-muted-foreground">Planned & saved</CardTitle>
              </CardHeader>
              <CardContent className="px-4 pb-4">
                <p className="text-2xl font-bold text-foreground">{plannedSaved}</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* ── SECTION 4: ACTIVITY CHART ── */}
        <section>
          <h2 className="text-xl font-heading font-semibold text-foreground mb-4">Your pause activity — last 14 days</h2>
          {hasChartData ? (
            <>
              <div className="bg-card border border-border rounded-lg p-4">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={chartData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={index} fill={entry.isToday ? "hsl(var(--accent))" : "hsl(var(--primary))"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-sm italic text-muted-foreground mt-3 text-center">
                Every bar is a moment you gave your brain a choice.
              </p>
            </>
          ) : (
            <div className="bg-card border border-border rounded-lg p-8 text-center">
              <p className="text-muted-foreground">Your first pause will appear here.</p>
            </div>
          )}
        </section>

        {/* ── SECTION 5: SAVED ITEMS ── */}
        <section>
          <h2 className="text-xl font-heading font-semibold text-foreground mb-1">Your shopping list</h2>
          <p className="text-sm text-muted-foreground mb-4">Things you paused on instead of buying.</p>

          {savedItems.length > 0 ? (
            <div className="space-y-3">
              {savedItems.map((item) => {
                const age = agePill(item.created_at);
                const d = daysAgo(item.created_at);
                return (
                  <Card key={item.id} className="p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="font-semibold text-foreground">{item.site}</span>
                          <span className={`inline-flex text-xs px-2 py-0.5 rounded-full border ${age.className}`}>
                            {age.label}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">
                          {item.product || `Item from ${item.site}`}
                        </p>
                        <div className="flex items-center gap-3 mt-1">
                          {item.price != null && (
                            <span className="text-sm font-semibold text-accent">£{item.price.toFixed(2)}</span>
                          )}
                          <span className="text-xs text-muted-foreground">Saved {d} day{d !== 1 ? "s" : ""} ago</span>
                        </div>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        {item.url && (
                          <Button variant="outline" size="sm" asChild>
                            <a href={item.url} target="_blank" rel="noopener noreferrer">Buy now →</a>
                          </Button>
                        )}
                        <Button size="sm" onClick={() => handleMovedOn(item)}>
                          I've moved on ✓
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="bg-card border border-border rounded-lg p-8 text-center">
              <p className="text-muted-foreground">Nothing saved yet. Next time you feel an impulse, save it here instead.</p>
            </div>
          )}

          <p className="text-xs italic text-muted-foreground mt-4 text-center">
            Research shows desire for impulse purchases drops significantly within 24 hours. (MacKillop et al., 2016)
          </p>
        </section>

        {/* ── SECTION 6: ACHIEVEMENTS ── */}
        <section>
          <h2 className="text-xl font-heading font-semibold text-foreground mb-4">Your badges</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {ACHIEVEMENTS.map((ach) => {
              const earned = profile ? ach.check(profile, allPauses, allSavedItems) : false;
              return (
                <div
                  key={ach.id}
                  className={`rounded-lg border p-4 text-center transition-all ${
                    earned
                      ? "bg-accent/10 border-accent shadow-sm"
                      : "bg-muted/30 border-border opacity-60"
                  }`}
                >
                  <div className="text-2xl mb-1">{ach.emoji}</div>
                  <p className={`text-sm font-semibold ${earned ? "text-accent" : "text-muted-foreground"}`}>
                    {ach.name}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{ach.condition}</p>
                  {earned && (
                    <Badge variant="secondary" className="mt-2 text-xs">Earned ✓</Badge>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ── SECTION 7: ACCOUNT ── */}
        <section>
          <h2 className="text-xl font-heading font-semibold text-foreground mb-4">Account</h2>
          <Accordion type="single" collapsible className="bg-card border border-border rounded-lg">
            <AccordionItem value="membership" className="border-b border-border px-4">
              <AccordionTrigger className="text-sm font-medium">
                Membership: {profile?.is_pro ? "Pro ⭐" : "Free"}
              </AccordionTrigger>
              <AccordionContent>
                {profile?.is_pro ? (
                  <p className="text-sm text-muted-foreground">
                    You're a Pro member since {profile.pro_activated_at ? new Date(profile.pro_activated_at).toLocaleDateString() : "recently"}. Thank you for supporting Dopamine Delay!
                  </p>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">Upgrade to Pro to unlock:</p>
                    <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                      <li>Advanced analytics & insights</li>
                      <li>Unlimited saved items history</li>
                      <li>Custom pause strategies</li>
                      <li>Priority support</li>
                    </ul>
                    <Button size="sm" asChild>
                      <a href="/pricing">Upgrade for £4.99/month →</a>
                    </Button>
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="password" className="border-b border-border px-4">
              <AccordionTrigger className="text-sm font-medium">Change password</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-3">
                  We'll send a password reset link to your email.
                </p>
                <Button variant="outline" size="sm" onClick={handleChangePassword}>
                  Send reset email
                </Button>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="delete" className="px-4">
              <AccordionTrigger className="text-sm font-medium text-destructive">Delete my account</AccordionTrigger>
              <AccordionContent>
                <p className="text-sm text-muted-foreground mb-3">
                  This will permanently delete your account and all data. This action cannot be undone.
                </p>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="destructive" size="sm">Delete my account</Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently delete your account, all your pauses, saved items, and points. This cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleDeleteAccount}>Yes, delete everything</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </section>
      </div>
    </div>
  );
};

export default Dashboard;
