import { motion, type Variants } from "framer-motion";
import { Pause, Shield, Brain, Timer, Star, Sparkles, ArrowDown } from "lucide-react";
import logo from "@/assets/logo.png";
import heroLogo from "@/assets/logo-hero.png";
import StickyNav from "@/components/StickyNav";

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: "easeOut" as const },
  }),
};

const Hero = () => (
  <section className="relative min-h-screen flex items-center justify-center overflow-hidden px-6 pt-24 pb-16">
    <div className="absolute inset-0 opacity-20 pointer-events-none"
      style={{
        backgroundImage: "radial-gradient(circle at 30% 40%, hsl(163 48% 33% / 0.15) 0%, transparent 50%), radial-gradient(circle at 70% 60%, hsl(40 76% 44% / 0.12) 0%, transparent 50%)",
      }}
    />
    <div className="max-w-4xl mx-auto text-center relative z-10">
      <motion.div variants={fadeUp} initial="hidden" animate="visible" custom={0}>
        <img src={heroLogo} alt="Dopamine Delay" className="max-w-xs sm:max-w-sm md:max-w-md mx-auto mb-8" />
      </motion.div>
      <motion.div variants={fadeUp} initial="hidden" animate="visible" custom={0.5}>
        <span className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-6">
          <Pause className="w-3.5 h-3.5" /> Chrome Extension for ADHD
        </span>
      </motion.div>
      <motion.h1
        className="font-heading text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight leading-tight mb-6"
        variants={fadeUp} initial="hidden" animate="visible" custom={1}
      >
        Pause before you{" "}
        <span className="text-gradient">purchase</span>
      </motion.h1>
      <motion.p
        className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
        variants={fadeUp} initial="hidden" animate="visible" custom={2}
      >
        Dopamine Delay intercepts checkout pages and gives your prefrontal cortex a moment to weigh in — working <em>with</em> your brain, not against it.
      </motion.p>
      <motion.div
        className="flex flex-col sm:flex-row gap-4 justify-center"
        variants={fadeUp} initial="hidden" animate="visible" custom={3}
      >
        <a
          href="https://github.com/glcook74/pause-before-purchase"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-8 py-4 text-primary-foreground font-semibold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all hover:-translate-y-0.5"
        >
          Get the Extension
        </a>
        <a
          href="#how-it-works"
          className="inline-flex items-center justify-center gap-2 rounded-xl border-2 border-foreground/15 px-8 py-4 font-semibold text-lg hover:bg-foreground/5 transition-all"
        >
          Learn More <ArrowDown className="w-4 h-4" />
        </a>
      </motion.div>
    </div>
  </section>
);

const features = [
  {
    icon: Brain,
    title: "Impulse Classification",
    desc: "\"Is this necessary, planned, or impulsive?\" — naming the impulse activates prefrontal regions that reduce its emotional intensity.",
  },
  {
    icon: Timer,
    title: "Smart Pause Timer",
    desc: "10–60 second pause that scales with purchase size and time of day. Longer pauses for big purchases and late-night shopping.",
  },
  {
    icon: Sparkles,
    title: "Dopamine Redirect",
    desc: "Rotating alternatives — music, movement, puzzles, breathing — that satisfy your dopamine-seeking brain without spending.",
  },
  {
    icon: Star,
    title: "Delay Points",
    desc: "Variable reward system that activates dopamine pathways for healthy behaviours. Earn points for pausing, saving, and moving on.",
  },
  {
    icon: Shield,
    title: "Dark Pattern Alerts",
    desc: "Detects urgency tactics like \"Only 3 left!\" and names them, reducing their manipulative effect on ADHD brains.",
  },
  {
    icon: Pause,
    title: "Save for Later",
    desc: "Activates future-oriented thinking. Items saved can be re-evaluated 24–48 hours later, when desire has typically faded.",
  },
];

const Features = () => (
  <section id="how-it-works" className="py-24 px-6">
    <div className="max-w-6xl mx-auto">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
          Built for how your brain <span className="text-gradient">actually works</span>
        </h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Every feature is grounded in ADHD neuroscience research — not willpower myths.
        </p>
      </motion.div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            className="group rounded-2xl bg-card border border-border p-8 hover:shadow-lg hover:shadow-primary/5 transition-all hover:-translate-y-1"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08, duration: 0.5 }}
          >
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/15 transition-colors">
              <f.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="font-heading text-xl font-semibold mb-3">{f.title}</h3>
            <p className="text-muted-foreground leading-relaxed">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const science = [
  { title: "Dopamine Reward Deficit", author: "Volkow et al., 2009", text: "ADHD brains have lower baseline dopamine. We redirect that drive toward healthier sources instead of blocking it." },
  { title: "Delay Discounting", author: "Research-backed", text: "A brief 10–30 second pause interrupts the impulse-to-action pipeline, allowing prefrontal evaluation." },
  { title: "Affect Labelling", author: "Lieberman et al., 2007", text: "Naming an impulse activates prefrontal regions that reduce emotional intensity. The classification is therapeutic, not judgmental." },
  { title: "Novelty Seeking", author: "Black et al., 2012", text: "Alternatives rotate randomly on each visit to maintain novelty value and engagement for ADHD brains that habituate quickly." },
];

const Science = () => (
  <section id="science" className="py-24 px-6 bg-secondary/50">
    <div className="max-w-5xl mx-auto">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
          The science behind the <span className="text-gradient">pause</span>
        </h2>
        <p className="text-muted-foreground text-lg max-w-xl mx-auto">
          Grounded in peer-reviewed ADHD neuroscience, not pop psychology.
        </p>
      </motion.div>
      <div className="grid sm:grid-cols-2 gap-6">
        {science.map((s, i) => (
          <motion.div
            key={s.title}
            className="rounded-2xl bg-card border border-border p-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
          >
            <p className="text-xs font-semibold uppercase tracking-wider text-accent mb-2">{s.author}</p>
            <h3 className="font-heading text-xl font-semibold mb-3">{s.title}</h3>
            <p className="text-muted-foreground leading-relaxed">{s.text}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const pointsTable = [
  { action: "First install (welcome)", points: "+50" },
  { action: "Complete pause classification", points: "+5" },
  { action: "Save for later", points: "+15" },
  { action: "Remove saved item", points: "+10" },
  { action: "7-day streak", points: "+25" },
];

const Points = () => (
  <section id="points" className="py-24 px-6">
    <div className="max-w-3xl mx-auto">
      <motion.div
        className="text-center mb-12"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <h2 className="font-heading text-3xl sm:text-4xl font-bold mb-4">
          Earn <span className="text-gradient">Delay Points</span>
        </h2>
        <p className="text-muted-foreground text-lg">Reward your brain for healthy choices.</p>
      </motion.div>
      <motion.div
        className="rounded-2xl bg-card border border-border overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        {pointsTable.map((row, i) => (
          <div key={row.action} className={`flex justify-between items-center px-8 py-5 ${i < pointsTable.length - 1 ? "border-b border-border" : ""}`}>
            <span className="font-medium">{row.action}</span>
            <span className="font-heading text-xl font-bold text-accent">{row.points}</span>
          </div>
        ))}
      </motion.div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="border-t border-border py-12 px-6">
    <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <img src={logo} alt="Dopamine Delay" className="h-8" />
      </div>
      <p className="text-sm text-muted-foreground">Working with your brain, not against it.</p>
      <a
        href="https://github.com/glcook74/pause-before-purchase"
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm text-primary hover:underline"
      >
        View on GitHub
      </a>
    </div>
  </footer>
);

const freePlan = {
  name: "Free",
  price: "£0",
  period: "forever",
  features: [
    "Pause timer",
    "Impulse classification",
    "Delay Points",
    "Save for Later",
    "Basic dopamine redirects",
  ],
};

const proPlan = {
  name: "Pro",
  price: "£4.99",
  period: "one-time",
  features: [
    "Everything in Free",
    "Dark Pattern Alerts",
    "Custom pause durations",
    "Detailed spending stats",
    "Priority support",
  ],
};

const Pricing = () => (
  <section id="pricing" className="py-24 px-6 bg-secondary/50">
    <div className="max-w-4xl mx-auto">
      <motion.div
        className="text-center mb-16"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
      >
        <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">
          Choose your <span className="text-gradient">plan</span>
        </h2>
        <p className="text-muted-foreground text-lg max-w-xl mx-auto">
          Start free. Upgrade when you're ready for the full toolkit.
        </p>
      </motion.div>
      <div className="grid sm:grid-cols-2 gap-8">
        {/* Free */}
        <motion.div
          className="rounded-2xl bg-card border border-border p-8 flex flex-col"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="font-heading text-2xl font-bold mb-1">{freePlan.name}</h3>
          <p className="text-muted-foreground text-sm mb-6">{freePlan.price} — {freePlan.period}</p>
          <ul className="space-y-3 mb-8 flex-1">
            {freePlan.features.map((f) => (
              <li key={f} className="flex items-start gap-2 text-muted-foreground">
                <span className="text-primary mt-0.5">✓</span> {f}
              </li>
            ))}
          </ul>
          <a
            href="https://github.com/glcook74/pause-before-purchase"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center rounded-xl border-2 border-foreground/15 px-6 py-3 font-semibold hover:bg-foreground/5 transition-all"
          >
            Get Free
          </a>
        </motion.div>

        {/* Pro */}
        <motion.div
          className="rounded-2xl bg-card border-2 border-primary p-8 flex flex-col relative"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1, duration: 0.5 }}
        >
          <span className="absolute -top-3 right-6 inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
            <Sparkles className="w-3 h-3" /> Recommended
          </span>
          <h3 className="font-heading text-2xl font-bold mb-1">{proPlan.name}</h3>
          <p className="text-muted-foreground text-sm mb-6">{proPlan.price} — {proPlan.period}</p>
          <ul className="space-y-3 mb-8 flex-1">
            {proPlan.features.map((f) => (
              <li key={f} className="flex items-start gap-2 text-muted-foreground">
                <span className="text-primary mt-0.5">✓</span> {f}
              </li>
            ))}
          </ul>
          <a
            href="https://github.com/glcook74/pause-before-purchase"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center rounded-xl bg-primary px-6 py-3 text-primary-foreground font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all hover:-translate-y-0.5"
          >
            Get Pro
          </a>
        </motion.div>
      </div>
    </div>
  </section>
);

const Index = () => (
  <main className="min-h-screen">
    <StickyNav />
    <Hero />
    <Features />
    <Science />
    <Points />
    <Pricing />
    <Footer />
  </main>
);

export default Index;
